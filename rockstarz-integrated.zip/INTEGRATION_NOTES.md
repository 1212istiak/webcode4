# Integration Notes: Frontend to Backend API

## Overview
Your uploaded HTML file (`voice-of-rockstarz-dynamic.html`) uses **localStorage** for data persistence, while the Node.js backend uses **MongoDB** with a REST API.

## Key Differences

### Uploaded HTML (localStorage-based)
- Stores data in browser's localStorage
- All data is client-side only
- No server required
- Data persists only in the browser

### Backend (API-based)
- Uses MongoDB for persistent server-side storage
- Provides REST API endpoints
- Supports JWT authentication for admin operations
- Images stored on Cloudinary or local disk

## Integration Strategy

The uploaded HTML has been placed in `/public/index.html` of the backend. However, **the JavaScript code needs to be updated** to use the backend API instead of localStorage.

### Required Changes to JavaScript:

1. **Remove localStorage usage** - Replace with API calls
2. **Add API base URL configuration** - Point to backend endpoints
3. **Add authentication handling** - JWT token management for admin operations
4. **Update data loading** - Fetch episodes and cards from `/api/episodes` and `/api/cards`
5. **Update CRUD operations** - Use POST/PUT/DELETE to backend instead of localStorage

## API Endpoints Available

### Episodes (Public)
- `GET /api/episodes` - Get all episodes
- `GET /api/episodes/:id` - Get single episode

### Episodes (Admin - requires JWT)
- `POST /api/episodes` - Create episode
- `PUT /api/episodes/:id` - Update episode
- `DELETE /api/episodes/:id` - Delete episode
- `POST /api/episodes/reorder` - Reorder episodes

### Cards (Public)
- `GET /api/cards` - Get all cards
- `GET /api/cards/:id` - Get single card

### Cards (Admin - requires JWT)
- `POST /api/cards` - Create card (with image upload)
- `PUT /api/cards/:id` - Update card
- `DELETE /api/cards/:id` - Delete card
- `POST /api/cards/reorder` - Reorder cards

### Admin Authentication
- `POST /api/admin/login` - Login and get JWT token
- `POST /api/admin/change-password` - Change admin password
- `GET /api/admin/verify` - Verify token validity

## Data Schema Mapping

### Episode (Backend MongoDB)
```javascript
{
  _id: ObjectId,
  num: String,           // Episode number (e.g., "01")
  title: String,         // Episode title
  description: String,   // Episode description
  dmEmbed: String,       // Dailymotion iframe code
  rumbleEmbed: String,   // Rumble iframe code
  order: Number,         // Display order
  createdAt: Date
}
```

### Card (Backend MongoDB)
```javascript
{
  _id: ObjectId,
  title: String,         // Card title
  genre: String,         // Genre/category
  badge: String,         // Badge text (e.g., "Watch Now")
  year: String,          // Year
  imageUrl: String,      // Image URL (from Cloudinary or /uploads/)
  imagePublicId: String, // Cloudinary public ID (for deletion)
  dmEmbed: String,       // Dailymotion iframe code
  rumbleEmbed: String,   // Rumble iframe code
  colorScheme: Number,   // Color scheme (1-4)
  order: Number,         // Display order
  createdAt: Date
}
```

## Next Steps for Full Integration

To complete the integration, you would need to:

1. **Update the frontend JavaScript** to replace localStorage calls with fetch() API calls
2. **Add JWT token management** in localStorage for admin authentication
3. **Update form submissions** to use FormData for image uploads
4. **Handle API errors** gracefully with try/catch blocks
5. **Add loading states** during API calls

## Environment Variables Required

Create a `.env` file in the project root with:

```
MONGO_URI=mongodb+srv://username:password@cluster.mongodb.net/rockstarz
JWT_SECRET=your_very_long_random_secret_string_here
ADMIN_PASSWORD=your_secure_password
PORT=3000
IMAGE_STORAGE=cloudinary
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret
```

## Current Status

✅ Backend code is ready
✅ API routes are implemented
✅ MongoDB models are defined
✅ Frontend HTML is placed in public folder

⚠️ **Frontend JavaScript needs to be updated** to use API instead of localStorage
