# Voice of Rockstarz — Complete Deployment Guide

## ✅ What's Ready

Your integrated project is now ready to deploy! Here's what you have:

- **Frontend**: `public/index.html` (your uploaded HTML file)
- **Backend**: Express.js server with MongoDB integration
- **API**: Full REST API for episodes, cards, and admin authentication
- **Authentication**: JWT-based admin panel
- **Image Storage**: Cloudinary integration for persistent image hosting

---

## 🚀 Quick Start for Deployment

### Step 1: Prepare Your Environment Variables

Create a `.env` file in the project root with your credentials:

```bash
# MongoDB Atlas Connection
MONGO_URI=mongodb+srv://USERNAME:PASSWORD@cluster0.xxxxx.mongodb.net/rockstarz

# JWT Secret (generate a long random string)
JWT_SECRET=your_very_long_random_secret_string_here_make_it_complex_at_least_32_chars

# Admin Password (set your own)
ADMIN_PASSWORD=your_secure_password_here

# Server Port
PORT=3000

# Image Storage (use cloudinary for production)
IMAGE_STORAGE=cloudinary

# Cloudinary Credentials (from your Cloudinary dashboard)
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret
```

### Step 2: Install Dependencies

```bash
npm install
```

### Step 3: Test Locally

```bash
npm run dev
```

Then open: **http://localhost:3000**

---

## 🌐 Deploy to Render (Recommended for Free Tier)

Render offers a free tier that works perfectly for this project.

### Steps:

1. **Push to GitHub**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/YOUR_USERNAME/rockstarz.git
   git push -u origin main
   ```

2. **Create Render Account**
   - Go to https://render.com
   - Sign up with GitHub

3. **Create New Web Service**
   - Click "New +" → "Web Service"
   - Connect your GitHub repository
   - Select the `rockstarz` repository

4. **Configure Render**
   - **Name**: rockstarz
   - **Environment**: Node
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Plan**: Free

5. **Add Environment Variables**
   - In Render dashboard → Your service → Environment
   - Add all variables from your `.env` file:
     - `MONGO_URI`
     - `JWT_SECRET`
     - `ADMIN_PASSWORD`
     - `PORT` (leave empty, Render sets this)
     - `IMAGE_STORAGE=cloudinary`
     - `CLOUDINARY_CLOUD_NAME`
     - `CLOUDINARY_API_KEY`
     - `CLOUDINARY_API_SECRET`

6. **Deploy**
   - Click "Deploy"
   - Render will build and deploy automatically
   - You'll get a free `.onrender.com` domain

---

## 🗄️ MongoDB Atlas Setup (Free Database)

1. **Create Account**
   - Go to https://cloud.mongodb.com
   - Sign up

2. **Create Free Cluster**
   - Click "Create" → "Cluster"
   - Select "M0 Free" tier
   - Choose your region
   - Click "Create"

3. **Create Database User**
   - Go to "Database Access"
   - Click "Add New Database User"
   - Set username and password
   - Click "Create User"

4. **Allow Network Access**
   - Go to "Network Access"
   - Click "Add IP Address"
   - Select "Allow access from anywhere" (0.0.0.0/0)
   - Click "Confirm"

5. **Get Connection String**
   - Click "Clusters" → "Connect"
   - Click "Connect your application"
   - Copy the connection string
   - Replace `<username>` and `<password>` with your credentials
   - Use this as your `MONGO_URI`

---

## 🖼️ Cloudinary Setup (Free Image Hosting)

1. **Create Account**
   - Go to https://cloudinary.com
   - Sign up (free tier: 25GB storage)

2. **Get API Credentials**
   - Go to Dashboard
   - Copy your:
     - **Cloud Name**
     - **API Key**
     - **API Secret**

3. **Add to Environment Variables**
   - `CLOUDINARY_CLOUD_NAME=your_cloud_name`
   - `CLOUDINARY_API_KEY=your_api_key`
   - `CLOUDINARY_API_SECRET=your_api_secret`

---

## 🔐 Admin Panel Usage

### Access Admin Panel

1. Open your deployed site
2. Click the **⚙ (gear)** icon in the top-right navigation
3. Or click the logo 5 times

### Login

- **Password**: Whatever you set in `ADMIN_PASSWORD`

### Add Episodes

1. Go to **Episodes** tab
2. Click **+ Add New Episode**
3. Fill in:
   - Episode number (e.g., "01")
   - Title
   - Description
   - Dailymotion embed code (paste full iframe)
   - Rumble embed code (paste full iframe)
4. Click **Save Episode**

### Add Cards (Browse Items)

1. Go to **Cards** tab
2. Click **+ Add New Card**
3. Fill in:
   - Title
   - Genre
   - Badge (e.g., "Watch Now", "Coming Soon")
   - Year
   - Upload thumbnail image
   - Dailymotion embed code
   - Rumble embed code
   - Color scheme (1-4)
4. Click **Save Card**

### Reorder Items

- Drag episodes or cards to reorder them
- Changes save automatically

### Change Password

1. Go to **Settings** tab
2. Enter new password twice
3. Click **Save Password**

---

## 📱 How to Get Embed Codes

### Dailymotion

1. Find video on Dailymotion
2. Click "Share" → "Embed"
3. Copy the `<iframe>` code
4. Paste in the form

### Rumble

1. Find video on Rumble
2. Click "Share" → "Embed"
3. Copy the `<iframe>` code
4. Paste in the form

---

## 🎯 API Endpoints Reference

### Public Endpoints (No Auth Required)

```
GET  /api/episodes         → Get all episodes
GET  /api/episodes/:id     → Get single episode
GET  /api/cards            → Get all cards
GET  /api/cards/:id        → Get single card
GET  /api/health           → Health check
```

### Admin Endpoints (Require JWT Token)

```
POST   /api/admin/login                    → Login (get token)
POST   /api/admin/change-password          → Change password
GET    /api/admin/verify                   → Verify token

POST   /api/episodes                       → Create episode
PUT    /api/episodes/:id                   → Update episode
DELETE /api/episodes/:id                   → Delete episode
POST   /api/episodes/reorder               → Reorder episodes

POST   /api/cards                          → Create card (multipart)
PUT    /api/cards/:id                      → Update card (multipart)
DELETE /api/cards/:id                      → Delete card
POST   /api/cards/reorder                  → Reorder cards
```

---

## 🆘 Troubleshooting

### "MongoDB connection failed"
- Check your `MONGO_URI` is correct
- Verify IP whitelist in MongoDB Atlas (should be 0.0.0.0/0)
- Ensure database user password is correct

### "Image upload failed"
- Check Cloudinary credentials are correct
- Verify `IMAGE_STORAGE=cloudinary` is set
- Check file size is under 100MB

### "Admin login not working"
- Verify `ADMIN_PASSWORD` is set in environment
- Clear browser cache and try again
- Check JWT token in browser localStorage

### "Cold start on Render"
- First request after inactivity takes 15-30 seconds
- This is normal on free tier
- Upgrade to paid tier to avoid cold starts

---

## 💰 Cost Breakdown (All Free)

| Service | What | Cost |
|---------|------|------|
| Render | Node.js Hosting | Free ($5 credit/mo) |
| MongoDB Atlas | Database | Free (512MB) |
| Cloudinary | Image Storage | Free (25GB) |
| **Total** | **Full Stack** | **$0/month** |

---

## 🎉 You're All Set!

Your Voice of Rockstarz site is ready to go live. Follow the Render deployment steps above and you'll have a fully functional streaming site in minutes!

**Need help?** Check the README.md in the project root for additional information.
