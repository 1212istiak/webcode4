# Voice of Rockstarz — Quick Start Guide

## What You Have

Your complete, integrated Voice of Rockstarz streaming platform is ready!

**Files Included:**
- `backend/rockstarz/` — Complete Node.js backend with Express server
- `DEPLOYMENT_GUIDE.md` — Step-by-step deployment instructions
- `INTEGRATION_NOTES.md` — Technical details about the integration

---

## 3-Step Setup

### 1. Install Dependencies
```bash
cd backend/rockstarz
npm install
```

### 2. Create .env File
Copy `.env.example` to `.env` and fill in your credentials:
```bash
cp .env.example .env
```

Edit `.env` with:
- Your MongoDB Atlas connection string
- Your Cloudinary API credentials
- A secure JWT secret
- Your admin password

### 3. Run the Server
```bash
npm start
```

Then open: **http://localhost:3000**

---

## Next Steps

1. **Read DEPLOYMENT_GUIDE.md** for detailed deployment instructions
2. **Set up MongoDB Atlas** (free database at https://cloud.mongodb.com)
3. **Set up Cloudinary** (free image hosting at https://cloudinary.com)
4. **Deploy to Render** (free Node.js hosting at https://render.com)

---

## Key Features

✅ Full-featured admin panel
✅ Episode management with drag-to-reorder
✅ Browse cards with image uploads
✅ Dailymotion & Rumble embed support
✅ JWT authentication
✅ MongoDB persistence
✅ Cloudinary image storage
✅ Responsive design

---

## Project Structure

```
backend/rockstarz/
├── server.js              ← Main Express server
├── package.json           ← Dependencies
├── .env.example           ← Environment template
├── models/
│   ├── Episode.js         ← Episode schema
│   └── Card.js            ← Card schema
├── routes/
│   ├── episodes.js        ← Episode API
│   ├── cards.js           ← Card API
│   └── admin.js           ← Admin auth
├── middleware/
│   └── auth.js            ← JWT middleware
├── public/
│   └── index.html         ← Your frontend
└── uploads/               ← Local image storage (dev)
```

---

## Admin Panel

**Access:** Click the ⚙ icon in top-right or click logo 5 times

**Default password:** Set in ADMIN_PASSWORD env variable

**Features:**
- Add/edit/delete episodes
- Add/edit/delete cards with image uploads
- Drag to reorder
- Change password
- Export/import data

---

## Support

For detailed information, see:
- `DEPLOYMENT_GUIDE.md` — Deployment instructions
- `INTEGRATION_NOTES.md` — Technical details
- `backend/rockstarz/README.md` — API reference

---

## Cost

**Completely free!**
- Render: Free tier
- MongoDB Atlas: Free 512MB cluster
- Cloudinary: Free 25GB storage

Total: $0/month for a fully functional streaming platform!

---

Ready to deploy? Follow the DEPLOYMENT_GUIDE.md!
